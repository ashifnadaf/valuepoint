const mongoose = require("mongoose");
//const { MongoDBNamespace } = require("mongoose"/node_modules/mongodb);
const Schema = mongoose.Schema;
const schema = new Schema({

    name: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    }
})
const Users = mongoose.model("users", schema);
module.exports = Users;