import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { APIService } from '../api.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  employee:any;
   id:string | null = "";

   constructor(private api : APIService,  private router :Router, private activatedRoute: ActivatedRoute) {
   }
 
   ngOnInit(): void {
     this.id = this.activatedRoute.snapshot.paramMap.get("id");
     if(this.id != "0")
     {
       let apiurl = "employees/get";
       let data = this.api.post(apiurl, { data: { id: this.id } });
       data.subscribe((mydata: any) => {
         this.employee = mydata.data;
         this.show();
       });
     }
     this.show();
   }
 
   show = ()=>{
     this.employee = new FormGroup({
       id: new FormControl(this.employee == null ? "" : this.employee._id),
       empid: new FormControl(this.employee == null ? "" : this.employee.empid, Validators.compose([Validators.required])),
       name: new FormControl(this.employee == null ? "" : this.employee.name, Validators.compose([Validators.required])),
       password: new FormControl(this.employee == null ? "" : this.employee.password, Validators.compose([Validators.required])),
       
       
     });
   }
 
   submit = (employee: any) => {
     let apiurl = "employees/save";
     let data = this.api.post(apiurl, { data: employee });
     data.subscribe((mydata: any) => {
       this.router.navigate(["admin/employees"]);
     });
   }
 
 

}
